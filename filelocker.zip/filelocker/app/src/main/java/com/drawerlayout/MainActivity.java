package com.drawerlayout;

import android.annotation.SuppressLint;
import android.app.ActionBar;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    private static final String TAG = "MainActivity";
    //    private DrawerLayout drawerLayout;
//    private ActionBarDrawerToggle toggle;
    private ActionBar actionBar;
    private DrawerLayout drawer_layout;
    private ListView list_left_drawer;
    private ArrayList<Item> menuLists;
    private MyListAdapter<Item> myAdapter = null;
    private Toolbar toolbar;
    private ActionBarDrawerToggle actionBarDrawerToggle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        createFolders();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.about:
                new AlertDialog.Builder(MainActivity.this).setTitle("About")
                        .setMessage("This app helps you manage multimedia files and lock selected files from others.")
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        }).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void initViews() {
        toolbar = (Toolbar) findViewById(R.id.toolbar);
        drawer_layout = (DrawerLayout) findViewById(R.id.drawer_layout);
        list_left_drawer = (ListView) findViewById(R.id.list_left_drawer);

        toolbar.setTitle("File Locker");
        toolbar.setTitleTextColor(Color.parseColor("#ffffff"));
        setSupportActionBar(toolbar);
        actionBarDrawerToggle = new ActionBarDrawerToggle(MainActivity.this, drawer_layout, toolbar, R.string.drawer_open, R.string.drawer_close);
        actionBarDrawerToggle.syncState();
        drawer_layout.setDrawerListener(actionBarDrawerToggle);

        menuLists = new ArrayList<Item>();
        menuLists.add(new Item(R.mipmap.iv_menu_realtime, "Select Audios "));
        menuLists.add(new Item(R.mipmap.iv_menu_alert, "Select Videos"));
        menuLists.add(new Item(R.mipmap.iv_menu_trace, "Select Images"));
        menuLists.add(new Item(R.mipmap.iv_menu_settings, "Select Docs"));
        menuLists.add(new Item(R.mipmap.iv_menu_realtime, "Locker vault"));

        myAdapter = new MyListAdapter<Item>(menuLists, R.layout.item_list) {
            @Override
            public void bindView(ViewHolder holder, Item obj) {
                holder.setImageResource(R.id.img_icon, obj.getIconId());
                holder.setText(R.id.txt_content, obj.getIconName());
            }
        };
        list_left_drawer.setAdapter(myAdapter);
        list_left_drawer.setOnItemClickListener(this);
    }


    /**
     * @param parent
     * @param view
     * @param position
     * @param id
     */
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        ContentFragment contentFragment = new ContentFragment();
//        Bundle args = new Bundle();
//        args.putString("text", menuLists.get(position).getIconName());
//        contentFragment.setArguments(args);
        FragmentManager fm = getSupportFragmentManager();
        switch (position) {
            case 0:
                toolbar.setTitle("Audios");
                fm.beginTransaction().replace(R.id.ly_content, new AudioScanFragment()).commit();
                break;
            case 1:
                toolbar.setTitle("Videos");
                fm.beginTransaction().replace(R.id.ly_content, new VideoScanFragment()).commit();
                break;
            case 2:
                toolbar.setTitle("Images");
                fm.beginTransaction().replace(R.id.ly_content, new ImageScanFragment()).commit();
                break;
            case 3:
                toolbar.setTitle("Documents");
                fm.beginTransaction().replace(R.id.ly_content, new DocScanFragment()).commit();
                break;
            case 4:
                toolbar.setTitle("Vaults");
                fm.beginTransaction().replace(R.id.ly_content, new VaultFragment()).commit();
                break;

        }
        drawer_layout.closeDrawer(list_left_drawer);
    }

    @SuppressLint("NewApi")
    private void initActionBar() {
        actionBar = super.getActionBar();
        actionBar.show();
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayShowTitleEnabled(false);
        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setHomeAsUpIndicator(R.mipmap.com_btn);
        Drawable colorDrawable = new
                ColorDrawable(getResources().getColor(android.R.color.transparent));
        actionBar.setIcon(colorDrawable);
        actionBar.setDisplayShowCustomEnabled(true);
        TextView tvTitle = new TextView(this);
        tvTitle.setText("HomePage");
        tvTitle.setTextColor(Color.WHITE);
        tvTitle.setTextSize(18);
        tvTitle.setGravity(Gravity.CENTER);
        ActionBar.LayoutParams params = new ActionBar.LayoutParams(ActionBar.LayoutParams.MATCH_PARENT, ActionBar.LayoutParams.WRAP_CONTENT);
        tvTitle.setLayoutParams(params);
        actionBar.setCustomView(tvTitle);
    }

//    private void initDrawerLayout() {
//        drawerLayout = (DrawerLayout) super.findViewById(R.id.drawer_layout);
//        drawerLayout.setScrimColor(Color.TRANSPARENT);
//		right_sliding=super.findViewById(R.id.right_sliding);
//        toggle = new ActionBarDrawerToggle(this, drawerLayout,
//                R.mipmap.back_move_details_normal, R.string.drawer_open
//                , R.string.drawer_close) {
//
//            @Override
//            public void onDrawerClosed(View drawerView) {
//                // TODO Auto-generated method stub
//                super.onDrawerClosed(drawerView);
//            }
//
//            @Override
//            public void onDrawerOpened(View drawerView) {
//                // TODO Auto-generated method stub
//                super.onDrawerOpened(drawerView);
//            }
//
//        };
//        drawerLayout.setDrawerListener(toggle);
    //drawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
    //drawerLayout.openDrawer(right_sliding);
//    }

    private void createFolders() {
        isExist("/sdcard/AFileLocker");
        isExist("/sdcard/AFileLocker/vault");
        isExist("/sdcard/AFileLocker/vault/image");
        isExist("/sdcard/AFileLocker/vault/audio");
        isExist("/sdcard/AFileLocker/vault/video");
        isExist("/sdcard/AFileLocker/vault/document");
        isExist("/sdcard/AFileLocker/vault/temp");
        isExist("/sdcard/AFileLocker/vault0");
        isExist("/sdcard/AFileLocker/vault0/image");
        isExist("/sdcard/AFileLocker/vault0/audio");
        isExist("/sdcard/AFileLocker/vault0/video");
        isExist("/sdcard/AFileLocker/vault0/document");
        isExist("/sdcard/AFileLocker/vault0/temp");
    }


    private void isExist(String path) {
        File file = new File(path);
        if (!file.exists()) file.mkdir();
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.i(TAG, "onStop");
        clearCaches(new File(FileInfo.VAULT_AUDIO_CACHE_PATH));
        clearCaches(new File(FileInfo.VAULT_VIDEO_CACHE_PATH));
        clearCaches(new File(FileInfo.VAULT_IMAGE_CACHE_PATH));
        clearCaches(new File(FileInfo.VAULT_DOC_CACHE_PATH));
        Log.i(TAG, "finished!");
    }

//    @Override
//    protected void onDestroy() {
//        super.onDestroy();
//        Log.i(TAG, "onDestroy");
//        clearCaches(new File(FileInfo.VAULT_AUDIO_CACHE_PATH));
//        clearCaches(new File(FileInfo.VAULT_VIDEO_CACHE_PATH));
//        clearCaches(new File(FileInfo.VAULT_IMAGE_CACHE_PATH));
//        clearCaches(new File(FileInfo.VAULT_DOC_CACHE_PATH));
//        Log.i(TAG,"finished!");
//    }

    private void clearCaches(File file) {
        if (file.exists()) {
            File[] files = file.listFiles();
            if (files.length != 0)
                for (File file2 : files)
                    if (file2.exists()) file2.delete();
                    else Log.i(TAG, file.getName() + " clear up !");
        } else {
            Log.i(TAG, "File is not existed");
        }
    }

    // duration between back button clicked

    private long exitTime = 0;

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK
                && event.getAction() == KeyEvent.ACTION_DOWN) {
            if ((System.currentTimeMillis() - exitTime) > 2000) {
                Toast.makeText(getApplicationContext(), "Exit if pressing again! ", Toast.LENGTH_SHORT).show();
                exitTime = System.currentTimeMillis();
            } else {
                finish();
            }
            return true;
        }

        return super.onKeyDown(keyCode, event);
    }
}
