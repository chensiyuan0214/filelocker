package com.drawerlayout;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.Toast;

import com.utils.AESUtils;
import com.utils.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class ImageScanFragment extends Fragment {
    private static final String TAG = "ImageScanFragment";
    private static final String VAULT_IMAGE_PATH = "/AFileLocker/vault/image";
    private ProgressDialog mProgressDialog;
    private MyAdapter mAdapter;
    private GridView gv;
    List<String> fileAbsPath;
    List<String> fileNames;
    private ImageButton imgBtn_select;
    private View view_fgcontent;
    private List<Integer> moveAndEncryptSuccessItems;
    /**
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        queryFiles();
        view_fgcontent = inflater.inflate(R.layout.fg_content, container, false);
        gv = (GridView) view_fgcontent.findViewById(R.id.tv_content);
        mAdapter = new MyAdapter(getActivity(), fileAbsPath,
                R.layout.grid_item2, "sd");
        gv.setAdapter(mAdapter);
        mAdapter.notifyDataSetChanged();
        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                Log.i(TAG, "onItemClick");
//                startActivity(MyIntent.getImageFileIntent(fileNames.get(position)));
                Toast.makeText(getActivity(), fileNames.get(position), Toast.LENGTH_SHORT).show();
            }
        });
        gv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                Log.i(TAG, "onItemLongClick");
                Toast.makeText(getActivity(), "click", Toast.LENGTH_SHORT).show();
                imgBtn_select = (ImageButton) view.findViewById(R.id.id_item_select);
                return true;
            }
        });
        ImageButton imgBtn_vault = (ImageButton) view_fgcontent.findViewById(R.id.imgBtn_vault);
        imgBtn_vault.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(getActivity()).setTitle("Warning")
                        .setMessage("Are you sure to lock the file and move it to vault ? ")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                moveAndEncryptSuccessItems = new ArrayList<Integer>();
                                if (!mAdapter.mSelectedImage.isEmpty()) {
                                    for (String filePath : mAdapter.mSelectedImage) {
                                        int position = fileAbsPath.indexOf(filePath);
                                        Log.i(TAG, filePath + "----" + position);
                                        moveAndEncrypt(position);
                                    }
                                    refreshView();
                                    mAdapter.mSelectedImage.clear();
//                                    String filePath = mAdapter.mSelectedImage.get(0);

                                } else {
                                    Toast.makeText(getActivity(), "No Image Selected!", Toast.LENGTH_SHORT).show();
                                }

                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mAdapter.mSelectedImage.clear();
                        gv.setAdapter(mAdapter);
                        mAdapter.notifyDataSetChanged();
                        dialog.dismiss();
                    }
                }).show();
            }
        });
        return view_fgcontent;
    }
    private void refreshView() {
        Collections.sort(moveAndEncryptSuccessItems);
        Collections.reverse(moveAndEncryptSuccessItems);
        System.out.println("moveAndEncryptSuccessItems:"+moveAndEncryptSuccessItems);
        for (int position : moveAndEncryptSuccessItems) {
            FileUtils.deleteFromMediaStore(getContext(),fileAbsPath.get(position));
            fileAbsPath.remove(position);
            fileNames.remove(position);
        }
        gv.setAdapter(mAdapter);
        mAdapter.notifyDataSetChanged();
    }
    private void moveAndEncrypt(int position) {
        String srcFile = fileAbsPath.get(position);
        String destDirName = Environment.getExternalStorageDirectory().getPath() + VAULT_IMAGE_PATH;
        Log.i(TAG, destDirName);
        boolean movedSuccess = FileUtils.moveFile(srcFile, destDirName);
        if (movedSuccess) {
            Toast.makeText(getActivity(), "move success", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getActivity(), "Encryption failed", Toast.LENGTH_SHORT).show();
        }
        //destFileName : moved file's path in vault
        String destFileName = destDirName + File.separator + fileNames.get(position);
//                                        String encryptedFile = destFileName.substring(0,destFileName.lastIndexOf(".")) + ".lock";
        String encryptedFile = destFileName + ".lock";
        try {
            AESUtils.encryptDocs(destFileName, encryptedFile);
            moveAndEncryptSuccessItems.add(position);
            Toast.makeText(getActivity(), "Moved and locked successfully ", Toast.LENGTH_SHORT).show();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void queryFiles() {
//        mProgressDialog = ProgressDialog.show(getActivity(), null, "正在加载...");
        fileAbsPath = new ArrayList<String>();
        fileNames = new ArrayList<String>();
        String[] projection = new String[]{MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DATA,
                MediaStore.Files.FileColumns.SIZE
        };
/*        Cursor cursor = getContext().getContentResolver().query(
                Uri.parse("content://media/external/file"),
                projection,
                MediaStore.Files.FileColumns.DATA + " like ?",
                new String[]{"%.jpg"},
                null);*/
        Cursor cursor = getContext().getContentResolver().query(
                Uri.parse("content://media/external/file"),
                projection,
                MediaStore.Files.FileColumns.DATA + " like ? or " + MediaStore.Files.FileColumns.DATA + " like ?",
                new String[]{"%.jpg", "%.png"},
                MediaStore.Files.FileColumns.DATE_MODIFIED + " DESC");
        // query jpeg and png images
//          Uri mImageUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
//        Cursor mCursor = mContentResolver.query(mImageUri, null,
//                MediaStore.Images.Media.MIME_TYPE + "=? or "
//                        + MediaStore.Images.Media.MIME_TYPE + "=?",
//                new String[] { "image/jpeg", "image/png" },
//                MediaStore.Images.Media.DATE_MODIFIED);
        if (cursor != null) {
            if (cursor.moveToFirst()) {

                int idindex = cursor
                        .getColumnIndex(MediaStore.Files.FileColumns._ID);
                int dataindex = cursor
                        .getColumnIndex(MediaStore.Files.FileColumns.DATA);
                int sizeindex = cursor
                        .getColumnIndex(MediaStore.Files.FileColumns.SIZE);
                do {
                    String id = cursor.getString(idindex);
                    String path = cursor.getString(dataindex);
                    String size = cursor.getString(sizeindex);
//                    docBean.setId(id);
//                    docBean.setPath(path);
//                    docBean.setSize(size);
                    //get images path
                    //2017/7/4 wechat  Tencent\MicroMsg\0c5fe8fde0eae5b3d157a2f24e4f8612
                    if(path.contains("/DCIM")||path.contains("/Tencent/Micromsg/camera")||path.contains("/Download")||path.contains("/AFileLocker")){
                        fileAbsPath.add(path);
                        int dot = path.lastIndexOf("/");
                        String name = path.substring(dot + 1);
                        fileNames.add(name);
                        System.out.println(id + "----" + path + "---" + size + "---");
                    }

                } while (cursor.moveToNext());
            }
        }
        cursor.close();
    }
}
