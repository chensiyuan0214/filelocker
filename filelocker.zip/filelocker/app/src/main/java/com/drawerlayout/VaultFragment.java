package com.drawerlayout;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import java.util.List;


public class VaultFragment extends Fragment implements View.OnClickListener{
    List<String> fileAbsPath  ;
    private TextView tv_content;
    private GridView gv;
    List<String> fileNames ;

    /**
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_vault, container, false);
        Button btn_audio = (Button) view.findViewById(R.id.btn_audio);
        Button btn_video = (Button) view.findViewById(R.id.btn_video);
        Button btn_image = (Button) view.findViewById(R.id.btn_image);
        Button btn_doc = (Button) view.findViewById(R.id.btn_doc);
        btn_audio.setOnClickListener(this);
        btn_video.setOnClickListener(this);
        btn_image.setOnClickListener(this);
        btn_doc.setOnClickListener(this);
//        this.getChildFragmentManager().beginTransaction().replace(R.id.vault_content,new VaultAudioFragment()).commit();

        return view;
    }


    @Override
    public void onClick(View v) {
//        FragmentManager fm = getActivity().getSupportFragmentManager();
        FragmentManager fm =  getChildFragmentManager();
        String fileEncrypted ="";
        String fileDecrypted ="";
        switch (v.getId()){
            case R.id.btn_audio :
//                fileEncrypted = AESUtils.encrypt("kkk","123456");
                fm.beginTransaction().replace(R.id.vault_content,new VaultAudioFragment()).commit();
                break;
            case R.id.btn_video :
                fm.beginTransaction().replace(R.id.vault_content,new VaultVideoFragment()).commit();
//                fm.beginTransaction().replace(R.id.vault_content,new VaultAudioFragment()).commit();
                break;
            case R.id.btn_image :
                fm.beginTransaction().replace(R.id.vault_content,new VaultImageFragment()).commit();
//                fm.beginTransaction().replace(R.id.vault_content,new VaultAudioFragment()).commit();
                break;
            case R.id.btn_doc :
                fm.beginTransaction().replace(R.id.vault_content,new VaultDocFragment()).commit();
//                fm.beginTransaction().replace(R.id.vault_content,new VaultAudioFragment()).commit();
                break;
        }
    }
}
