package com.drawerlayout;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ContentFragment extends Fragment {

    private TextView tv_content;
    private GridView gv;
    List<String> fileNames ;

    /**
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        queryFiles();
        View view = inflater.inflate(R.layout.fg_content, container, false);
        gv = (GridView) view.findViewById(R.id.tv_content);
//        gv.setAdapter(new MyGridviewAdapter(getActivity()));
//        String text = getArguments().getString("text");
//        tv_content.setText(text);
        List<Map<String, Object>> items = new ArrayList<Map<String,Object>>();
        for (int i = 0; i < fileNames.size(); i++) {
            Map<String, Object> item = new HashMap<String, Object>();
            item.put("imageItem", R.mipmap.audiopic);
            item.put("textItem", fileNames.get(i));
            items.add(item);
        }
        SimpleAdapter adapter = new SimpleAdapter(getActivity(),
                items,
                R.layout.grid_item,
                new String[]{"imageItem", "textItem"},
                new int[]{R.id.image_item, R.id.text_item});

        gv.setAdapter(adapter);
        gv.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            public void onItemClick(AdapterView<?> parent, View v, int position, long id)
            {
                Toast.makeText(getContext(), fileNames.get(position) , Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }

    public  void  queryFiles(){
        fileNames = new ArrayList<String>();
        String[] projection = new String[] { MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DATA,
                MediaStore.Files.FileColumns.SIZE
        };
        Cursor cursor = getContext().getContentResolver().query(
                Uri.parse("content://media/external/file"),
                projection,
                MediaStore.Files.FileColumns.DATA + " like ?",
                new String[]{"%.mp3"},
                null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {

                int idindex = cursor
                        .getColumnIndex(MediaStore.Files.FileColumns._ID);
                int dataindex = cursor
                        .getColumnIndex(MediaStore.Files.FileColumns.DATA);
                int sizeindex = cursor
                        .getColumnIndex(MediaStore.Files.FileColumns.SIZE);
                do {
                    String id = cursor.getString(idindex);
                    String path = cursor.getString(dataindex);
                    String size = cursor.getString(sizeindex);
//                    docBean.setId(id);
//                    docBean.setPath(path);
//                    docBean.setSize(size);
                    int dot=path.lastIndexOf("/");
                    String name=path.substring(dot+1);
                    fileNames.add(name);
                    Log.e("test",name);
                    System.out.println(id+"----"+path+"---"+size+"---");
                } while (cursor.moveToNext());
            }
        }
        cursor.close();
    }
    class MyGridviewAdapter extends BaseAdapter {
        private Context context;
        private Integer[] imgs = {
                R.mipmap.docpic, R.mipmap.docpic, R.mipmap.docpic,
                R.mipmap.docpic, R.mipmap.docpic, R.mipmap.docpic,
                R.mipmap.docpic, R.mipmap.docpic, R.mipmap.docpic,
                R.mipmap.docpic, R.mipmap.docpic, R.mipmap.docpic,
                R.mipmap.docpic, R.mipmap.docpic, R.mipmap.docpic,
                R.mipmap.docpic, R.mipmap.docpic, R.mipmap.docpic,
        };
        //picture paths
        private String pic_path = "/storage/emulated/0/DCIM/Camera/IMG_20161012_184728_HDR.jpg";
        MyGridviewAdapter(Context context){
            this.context = context;
        }
        public int getCount() {
            return imgs.length;
        }

        public Object getItem(int item) {
            return item;
        }

        public long getItemId(int id) {
            return id;
        }

        //创建View方法
        public View getView(int position, View convertView, ViewGroup parent) {
            ImageView imageView;
            if (convertView == null) {
                imageView = new ImageView(context);
                imageView.setLayoutParams(new GridView.LayoutParams(75, 75));//set ImageView layout
                imageView.setAdjustViewBounds(false);
                imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
                imageView.setPadding(8, 8, 8, 8);
            }
            else {
                imageView = (ImageView) convertView;
            }
//            imageView.setImageResource(imgs[position]);
            String path = Environment.getExternalStorageState()+"IMG_20161023_200100.jpg";

//            String path = Environment.getExternalStorageState()+"IMG_20161023_200100.jpg";
            File file = new File(path);
            System.out.println(file.exists()+"-------------------------"+ Environment.getExternalStorageDirectory().toString());
            //show ImageView
            Bitmap bm = BitmapFactory.decodeFile(path );
            imageView.setImageBitmap(bm);
//            if (file.exists()) {
//                Bitmap bm = BitmapFactory.decodeFile(pic_path);
//                imageView.setImageBitmap(bm);
//            }
            return imageView;
        }

    }
}
