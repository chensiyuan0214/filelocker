package com.drawerlayout;

import android.content.DialogInterface;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.utils.AESUtils;
import com.utils.FileUtils;
import com.utils.MyIntent;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class AudioScanFragment extends Fragment {
    private final String TAG = "AudioScanFragment";
    private static final String VAULT_AUDIO_PATH = "/AFileLocker/vault/audio";
    List<String> fileAbsPath;
    private GridView gv;
    List<String> fileNames;
    private ImageButton imgBtn_select;
    private View view_fgcontent;
    private List<Map<String, Object>> items;
    private SimpleAdapter adapter;
    private List<Integer> selectItems;
    private boolean isSelectedState = false;
    private ImageButton imgBtn_vault;
    private List<Integer> moveAndEncryptSuccessItems;
    private  Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
        }
    };

    /**
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        Log.i(TAG, "onCreateView");
        new Thread(new Runnable() {
            @Override
            public void run() {

            }
        }).start();
        queryFiles();
//        Looper.prepare();;
//        Handler handler ;
        view_fgcontent = inflater.inflate(R.layout.fg_content, container, false);
        imgBtn_vault = (ImageButton) view_fgcontent.findViewById(R.id.imgBtn_vault);
        gv = (GridView) view_fgcontent.findViewById(R.id.tv_content);
        items = new ArrayList<Map<String, Object>>();
        for (int i = 0; i < fileNames.size(); i++) {
            Map<String, Object> item = new HashMap<String, Object>();
            item.put("imageItem", R.mipmap.audiopic);
            item.put("textItem", fileNames.get(i));
            items.add(item);
        }

        adapter = new SimpleAdapter(getActivity(),
                items,
                R.layout.grid_item,
                new String[]{"imageItem", "textItem"},
                new int[]{R.id.image_item, R.id.text_item});
        gv.setAdapter(adapter);
        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                imgBtn_select = (ImageButton) v.findViewById(R.id.id_item_select);
                if (isSelectedState) {
                    if (imgBtn_select.getVisibility() == View.INVISIBLE) {
                        imgBtn_select.setVisibility(View.VISIBLE);
                        boolean b = selectItems.add(position);
                        imgBtn_select.setFocusable(false);
                        imgBtn_select.setClickable(false);
                    } else {
                        imgBtn_select.setVisibility(View.INVISIBLE);
                        boolean b = selectItems.remove(new Integer(position));
                        if (selectItems.isEmpty()) isSelectedState = false;
                    }
                } else {
                    String path = fileAbsPath.get(position);
                    if (path.endsWith("mp3"))
                        startActivity(MyIntent.getAudioFileIntent(path));
                    Log.i(TAG, fileAbsPath.get(position));
                    Toast.makeText(getContext(), fileAbsPath.get(position), Toast.LENGTH_SHORT).show();
                }

            }
        });

        gv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                imgBtn_select = (ImageButton) view.findViewById(R.id.id_item_select);
                // if the gridview is not selected state
                if (!isSelectedState) {
                    isSelectedState = true;
                    selectItems = new ArrayList<>();
                    imgBtn_select.setVisibility(View.VISIBLE);
                    boolean b = selectItems.add(position);
                    imgBtn_select.setFocusable(false);
                    imgBtn_select.setClickable(false);
                } else {
                    //the gridview is selected state
//                    imgBtn_select.setVisibility(View.INVISIBLE);
//                    Toast.makeText(getActivity(), isSelectedState +"", Toast.LENGTH_SHORT).show();
//                    isSelectedState = false ;
                }
                return true;
            }
        });
        imgBtn_vault.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isSelectedState) {
                    Toast.makeText(getActivity(), "Please select!", Toast.LENGTH_SHORT).show();
                    return;
                }
                new AlertDialog.Builder(getActivity()).setTitle("Warning")
                        .setMessage("Are you sure to lock the file and move it to vault ? ")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                isSelectedState = false;
                                if (!selectItems.isEmpty()) {
                                    moveAndEncryptSuccessItems = new ArrayList<Integer>();
                                    for (int position : selectItems) {
                                        Log.i(TAG, "----" + position);
                                        moveAndEncrypt(position);
                                    }
                                    refreshView();
                                    selectItems.clear();
                                } else {
                                    Toast.makeText(getActivity(), "No Audio Selected!", Toast.LENGTH_SHORT).show();
                                }
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        isSelectedState = false;
                        selectItems.clear();
                        gv.setAdapter(adapter);
                        adapter.notifyDataSetChanged();
                        dialog.dismiss();
                    }
                }).show();
            }
        });
        return view_fgcontent;
    }

    private void refreshView() {
        Collections.sort(moveAndEncryptSuccessItems);
        Collections.reverse(moveAndEncryptSuccessItems);
        System.out.println("moveAndEncryptSuccessItems:" + moveAndEncryptSuccessItems);
        for (int position : moveAndEncryptSuccessItems) {
            FileUtils.deleteFromMediaStore(getContext(),fileAbsPath.get(position));
            items.remove(position);
            fileAbsPath.remove(position);
            fileNames.remove(position);
        }
        gv.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    private void moveAndEncrypt(int position) {
        String srcFile = fileAbsPath.get(position);
        String destDirName = Environment.getExternalStorageDirectory().getPath() + VAULT_AUDIO_PATH;
        Log.i(TAG, destDirName);
        boolean movedSuccess = FileUtils.moveFile(srcFile, destDirName);
        if (movedSuccess) {
//            Toast.makeText(getActivity(), "move success", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getActivity(), "Encryption failed", Toast.LENGTH_SHORT).show();
        }
        //destFileName : moved file's path in vault
        String destFileName = destDirName + File.separator + fileNames.get(position);
//                                        String encryptedFile = destFileName.substring(0,destFileName.lastIndexOf(".")) + ".lock";
        String encryptedFile = destFileName + ".lock";
        try {
            Log.i(TAG, "dest file name:" + destFileName + " encryped file:" + encryptedFile);
            AESUtils.encryptDocs(destFileName, encryptedFile);
            moveAndEncryptSuccessItems.add(position);
            Toast.makeText(getActivity(), "Moved and locked successfully ", Toast.LENGTH_SHORT).show();
            Log.i(TAG, "locked success ");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    public void queryFiles() {
        //content://media/external/audio/media
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI ;
        fileAbsPath = new ArrayList<String>();
        fileNames = new ArrayList<String>();
        String[] projection = new String[]{MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DATA,
                MediaStore.Files.FileColumns.SIZE
        };

//        Uri mImageUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
//        Cursor cursor = getContext().getContentResolver().query(
//                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
//                projection,
//                null,
//                null,
//                null);
        Cursor cursor = getContext().getContentResolver().query(
                Uri.parse("content://media/external/file"),
                projection,
                MediaStore.Files.FileColumns.DATA + " like ?",
                new String[]{"%.mp3"},
                null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {

                int idindex = cursor
                        .getColumnIndex(MediaStore.Files.FileColumns._ID);
                int dataindex = cursor
                        .getColumnIndex(MediaStore.Files.FileColumns.DATA);
                int sizeindex = cursor
                        .getColumnIndex(MediaStore.Files.FileColumns.SIZE);
                do {
                    String id = cursor.getString(idindex);
                    String path = cursor.getString(dataindex);
                    String size = cursor.getString(sizeindex);

                    int dot = path.lastIndexOf("/");
                    fileAbsPath.add(path);
                    String name = path.substring(dot + 1);
                    fileNames.add(name);
                    Log.e("test", name);
                } while (cursor.moveToNext());
            }
        }
        cursor.close();
    }
}
