package com.drawerlayout;

import android.os.Environment;

/**
 * Created by jack on 2016/11/12.
 */
public class FileInfo {
    public  static  String VAULT_ROOT_PATH  = Environment.getExternalStorageDirectory().getPath() + "/AFileLocker/vault";
    public  static  String VAULT_AUDIO_CACHE_PATH  = VAULT_ROOT_PATH + "/audio/caches" ;
    public  static  String VAULT_VIDEO_CACHE_PATH  = VAULT_ROOT_PATH + "/video/caches" ;
    public  static  String VAULT_IMAGE_CACHE_PATH  = VAULT_ROOT_PATH + "/image/caches" ;
    public  static  String VAULT_DOC_CACHE_PATH  = VAULT_ROOT_PATH + "/document/caches" ;
}
