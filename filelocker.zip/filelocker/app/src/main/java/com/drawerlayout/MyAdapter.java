package com.drawerlayout;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

import com.utils.CommonAdapter;
import com.utils.ViewHolder;

import java.util.LinkedList;
import java.util.List;

public class MyAdapter extends CommonAdapter<String>
{

	private static final String TAG = "MyAdapter";

	public static List<String> mSelectedImage = new LinkedList<String>();


	private String mDirPath;

	public MyAdapter(Context context, List<String> mDatas, int itemLayoutId,
			String dirPath)
	{
		super(context, mDatas, itemLayoutId);
		this.mDirPath = dirPath;
	}

	@Override
	public void convert(final ViewHolder helper, final String item)
	{
		// set no_pic
		helper.setImageResource(R.id.id_item_image, R.mipmap.pictures_no);
		//set no_selected
				helper.setImageResource(R.id.id_item_select,
						R.mipmap.picture_unselected);
		//set images
//		helper.setImageByUrl(R.id.id_item_image, mDirPath + "/" + item);
		System.out.println(Log.i("item",item));
		helper.setImageByUrl(R.id.id_item_image, item);

		final ImageView mImageView = helper.getView(R.id.id_item_image);
		final ImageView mSelect = helper.getView(R.id.id_item_select);
		
		mImageView.setColorFilter(null);
		mImageView.setOnClickListener(new OnClickListener()
		{
			//选择，则将图片变暗，反之则反之
			@Override
			public void onClick(View v)
			{

				// selected
//				if (mSelectedImage.contains(mDirPath + "/" + item))
				if (mSelectedImage.contains(item))
				{
					mSelectedImage.remove(item);
//					mSelectedImage.remove(mDirPath + "/" + item);
					mSelect.setImageResource(R.mipmap.picture_unselected);
					mImageView.setColorFilter(null);
				} else
				// not selected
				{
//					mSelectedImage.add(mDirPath + "/" + item);
					mSelectedImage.add(item);
					mSelect.setImageResource(R.mipmap.pictures_selected);
					mImageView.setColorFilter(Color.parseColor("#77000000"));
				}
				for(String item:mSelectedImage)
					Log.i(TAG,item);

			}
		});
		
		/**
		 * selected images
		 */
		if (mSelectedImage.contains(mDirPath + "/" + item))
		{
			mSelect.setImageResource(R.mipmap.pictures_selected);
			mImageView.setColorFilter(Color.parseColor("#77000000"));
		}


	}
}
