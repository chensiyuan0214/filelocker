package com.drawerlayout;

import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import com.utils.AESUtils;
import com.utils.FileUtils;
import com.utils.MyIntent;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class VaultDocFragment extends Fragment {
    private final String TAG = "VaultDocFragment";
    private static final String IMAGE_REMOVE_PATH = "/AFileLocker/vault0/document";
    List<String> fileAbsPaths;
    private GridView gv;
    List<String> fileNames;
    private ImageButton imgBtn_select;
    private View view_fgcontent;
    private ImageButton imgBtn_vault;
    private List<Integer> selectItems;
    private SimpleAdapter mAdapter;
    private boolean isSelectedState = false;
    List<Map<String, Object>> items;
    private List<Integer> moveAndDecryptSuccessItems;

    /**
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        queryFiles();
        Log.i(TAG, "onCreateView---" + fileNames.size() + (this == null ? true : false));
        view_fgcontent = inflater.inflate(R.layout.fg_content, container, false);
        imgBtn_vault = (ImageButton) view_fgcontent.findViewById(R.id.imgBtn_vault);
        imgBtn_vault.setImageResource(R.mipmap.convert_back);

        gv = (GridView) view_fgcontent.findViewById(R.id.tv_content);

        items = new ArrayList<Map<String, Object>>();
        for (int i = 0; i < fileNames.size(); i++) {
            Map<String, Object> item = new HashMap<String, Object>();
            item.put("imageItem", R.mipmap.docpic);
            item.put("textItem", fileNames.get(i));//按序号添加ItemText
            items.add(item);
        }
        mAdapter = new SimpleAdapter(getActivity(),
                items,
                R.layout.grid_item,
                new String[]{"imageItem", "textItem"},
                new int[]{R.id.image_item, R.id.text_item});

        gv.setAdapter(mAdapter);
        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
//                Toast.makeText(getActivity(), position + "被点击了", Toast.LENGTH_SHORT).show();
                imgBtn_select = (ImageButton) v.findViewById(R.id.id_item_select);
                if (isSelectedState) {
                    if (imgBtn_select.getVisibility() == View.INVISIBLE) {
                        imgBtn_select.setVisibility(View.VISIBLE);
                        boolean b = selectItems.add(position);
                        imgBtn_select.setFocusable(false);
                        imgBtn_select.setClickable(false);
                    } else {
                        imgBtn_select.setVisibility(View.INVISIBLE);
                        boolean b = selectItems.remove(new Integer(position));
                        if (selectItems.isEmpty()) isSelectedState = false;
                    }
                } else {
                    decryptAndOpen(position);
                }
            }
        });
        gv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                imgBtn_select = (ImageButton) view.findViewById(R.id.id_item_select);
                // if the gridview is not selected state
                if (!isSelectedState) {
                    isSelectedState = true;
                    selectItems = new ArrayList<>();
                    imgBtn_select.setVisibility(View.VISIBLE);
                    boolean b = selectItems.add(position);
                    imgBtn_select.setFocusable(false);
                    imgBtn_select.setClickable(false);
                } else {
                    //the gridview is selected state
//                    imgBtn_select.setVisibility(View.INVISIBLE);
//                    Toast.makeText(getActivity(), isSelectedState +"", Toast.LENGTH_SHORT).show();
//                    isSelectedState = false ;
                }
                return true;
            }

        });
        imgBtn_vault.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!isSelectedState) {
                    Toast.makeText(getActivity(), "Please select!", Toast.LENGTH_SHORT).show();
                    return;
                }
                new AlertDialog.Builder(getActivity()).setTitle("Warning")
                        .setMessage("Are you sure to unlock the file and move it out vault ? ")
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                isSelectedState = false;
                                moveAndDecryptSuccessItems = new ArrayList<Integer>();
                                if (!selectItems.isEmpty()) {
                                    for (int position : selectItems) {
                                        Log.i(TAG, "----" + position);
                                        moveAndDecrypt(position);
                                    }
                                    refreshView();
                                    FileUtils.addToMeidaStore(getContext(), IMAGE_REMOVE_PATH);
                                    selectItems.clear();
                                } else {
                                    Toast.makeText(getActivity(), "No File Selected!", Toast.LENGTH_SHORT).show();
                                }

                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        isSelectedState = false;
                        selectItems.clear();
                        gv.setAdapter(mAdapter);
                        mAdapter.notifyDataSetChanged();
                        dialog.dismiss();
                    }
                }).show();
            }
        });
        return view_fgcontent;
    }

    private void refreshView() {
        Collections.sort(moveAndDecryptSuccessItems);
        Collections.reverse(moveAndDecryptSuccessItems);
        System.out.println("moveAndDecryptSuccessItems:" + moveAndDecryptSuccessItems);
        for (int position : moveAndDecryptSuccessItems) {
            items.remove(position);
            fileAbsPaths.remove(position);
            fileNames.remove(position);
        }
        gv.setAdapter(mAdapter);
        mAdapter.notifyDataSetChanged();
    }

    private void moveAndDecrypt(int position) {
        String path = fileAbsPaths.get(position);
        try {
            AESUtils.decryptDocs(path);
        } catch (Exception e) {
            e.printStackTrace();
        }
        String readFromCaches = FileUtils.getFileCachePath(path, position);
        String removePath = Environment.getExternalStorageDirectory().getPath() + IMAGE_REMOVE_PATH;
        Log.i(TAG, removePath);
        boolean moveSuccess = FileUtils.moveFile(readFromCaches, removePath);
        if (moveSuccess) {
            moveAndDecryptSuccessItems.add(position);
            Toast.makeText(getActivity(), "Unlocked and Removed", Toast.LENGTH_SHORT).show();
            new File(path).delete();
        } else {
            Toast.makeText(getActivity(), "Decryption Failed", Toast.LENGTH_SHORT).show();
        }

    }

    private void decryptAndOpen(int position) {
        String path = fileAbsPaths.get(position);
        try {
            AESUtils.decryptDocs(path);
        } catch (Exception e) {
            e.printStackTrace();
        }
        String readFromCaches = FileUtils.getFileCachePath(path, position);
//        String cachesDir = path.substring(0,path.lastIndexOf("/"))+"/caches";
//        String fileName = fileNames.get(position);
//        String newFileName = fileName.substring(0,fileName.lastIndexOf("."));
//        String readFromCaches = cachesDir+ File.separator + newFileName ;
        Log.i(TAG, path + " " + "cachePath:" + readFromCaches);
        if (readFromCaches.endsWith(".pdf")) {
            startActivity(MyIntent.getPdfFileIntent(readFromCaches));
        } else if (readFromCaches.endsWith(".txt")) {
            startActivity(MyIntent.getTextFileIntent(readFromCaches));
        }
    }

    public void queryFiles() {
        fileAbsPaths = new ArrayList<String>();
        fileNames = new ArrayList<String>();
        File file = new File(Environment.getExternalStorageDirectory().getPath() + "/AFileLocker/vault/document");
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            for (File file2 : files) {
                if (file2.isDirectory()) continue;
                String fileAbsPath = file2.getAbsolutePath();
                String fileName = fileAbsPath.substring(fileAbsPath.lastIndexOf("/") + 1);
                System.out.println("File Vault" + fileAbsPath + "---------" + fileName);
                fileAbsPaths.add(fileAbsPath);
                fileNames.add(fileName);
            }
        }
    }
}
