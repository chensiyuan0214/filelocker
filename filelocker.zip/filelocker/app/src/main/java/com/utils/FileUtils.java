package com.utils;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;

import java.io.File;


public class FileUtils {

    private static final String TAG = "FileUtils";

    public static boolean moveFile(String srcFileName, String destDirName) {
        File srcFile = new File(srcFileName);
        if (!srcFile.exists() || !srcFile.isFile()) {
            return false;
        }

        File destDir = new File(destDirName);
        if (!destDir.exists())
            destDir.mkdirs();
        //aes加密
//        String encryptedName = AESUtils.encrypt("aes",srcFile.getName());
        return srcFile.renameTo(new File(destDirName + File.separator + srcFile.getName()));
    }

    /**
     * @param path     the locked file absolute path
     * @param position file's position in gridview
     * @return
     */
    public static String getFileCachePath(String path, int position) {
        String cachesDir = path.substring(0, path.lastIndexOf("/")) + "/caches";
        String fileName = path.substring(path.lastIndexOf("/") + 1);  //e.g.  a.mp3.lock
        String newFileName = fileName.substring(0, fileName.lastIndexOf("."));
        String readFromCaches = cachesDir + File.separator + newFileName;
        Log.i(TAG, path + " " + "cachePath:" + readFromCaches);
        return readFromCaches;
    }

    public static boolean deleteFromMediaStore(Context context,String path) {
        ContentResolver cr = context.getContentResolver();
        int num = cr.delete(
                Uri.parse("content://media/external/file"),
                MediaStore.Files.FileColumns.DATA +" = ?",
                new String[]{path}
        );
        Log.i(TAG,num+"");
        if(num!=0)
            return true;
        else
            return false;
    }


    public static void addToMeidaStore(Context context, String vaultPath) {
        String vault0_path = Environment.getExternalStorageDirectory().getPath() + vaultPath;
        File file = new File(vault0_path);
        File[] files = file.listFiles();
        Uri uri = null;
        Intent mediaScanIntent = null;
        for (File file2 : files) {
            if (file2.exists()) {
                uri = Uri.fromFile(file2);
                mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE, uri);
                context.sendBroadcast(mediaScanIntent);
                String path = mediaScanIntent.getData().getPath();
                String externalStoragePath = Environment.getExternalStorageDirectory().getPath();
                Log.i("LOGTAG", "Androidyue onReceive intent= " + mediaScanIntent
                        + ";path=" + path + ";externalStoragePath=" +
                        externalStoragePath);
            }
        }
    }
}
